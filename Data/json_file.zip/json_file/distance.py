import json


with open('ameya_vriksh/ameya_vriksh_json/content/openpose/output/video_000000000000_keypoints.json') as f:
  data = json.load(f)

ary1 = data["people"][0]["pose_keypoints_2d"]
#print(ary1)

del ary1[2::3]

#print(ary1)

'''
with open('kaustuk_vriksh/kaustuk_vriksh_json/content/openpose/output/video_000000000000_keypoints.json') as f:
  data = json.load(f)

ary2 = data["people"][0]["pose_keypoints_2d"]
#print(ary2)

del ary2[2::3]

#print(ary2)



with open('ameya_tadasan/ameya_tadasan_json/content/openpose/output/video_000000000000_keypoints.json') as f:
  data = json.load(f)

ary1 = data["people"][0]["pose_keypoints_2d"]
#print(ary1)

del ary1[2::3]

#print(ary1)

'''

with open('kaustuk_tadasan/kaustuk_tadasan_json/content/openpose/output/video_000000000000_keypoints.json') as f:
  data = json.load(f)

ary2 = data["people"][0]["pose_keypoints_2d"]
#print(ary2)

del ary2[2::3]

#print(ary2)


from scipy.spatial import distance

result = distance.euclidean(ary1, ary2)
print(result)
